<div class="wt-dashboardtabs">
    <ul class="wt-tabstitle nav navbar-nav">
        <li class="nav-item">
            <a class="{{{ \Request::route()->getName()==='personalDetail'? 'active': '' }}}" href="{{{ route('adminPersonalDetail') }}}">{{{ trans('lang.admin_detail') }}}</a>
        </li>
    </ul>
</div>

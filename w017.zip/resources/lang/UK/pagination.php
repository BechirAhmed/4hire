<?php 

return [
    'previous' => '& laquo; Попередній',
    'next' => 'Далі & raquo;',
];
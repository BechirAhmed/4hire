<?php 

return [
    'password' => 'Les mots de passe doivent comporter au moins six caractères et correspondre à la confirmation.',
    'reset' => 'Votre mot de passe a été réinitialisé!',
    'sent' => 'Nous avons envoyé votre lien de réinitialisation de mot de passe par e-mail!',
    'token' => 'Ce jeton de réinitialisation de mot de passe n\'est pas valide.',
    'user' => 'Nous ne pouvons pas trouver un utilisateur avec cette adresse e-mail.',
];
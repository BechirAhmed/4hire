<?php 

return [
    'previous' => 'এবং laquo; আগে',
    'next' => 'পরবর্তী & raquo;',
];
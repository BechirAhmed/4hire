<?php 

return [
    'previous' => '＆laquo;上以前',
    'next' => '下一步＆raquo;',
];
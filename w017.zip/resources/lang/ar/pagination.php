<?php 

return [
    'previous' => 'وقوو]؛ سابق',
    'next' => 'التالي & raquo؛',
];
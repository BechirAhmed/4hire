<?php 

return [
    'previous' => '& laquo; Anterior',
    'next' => 'Próximo & raquo;',
];
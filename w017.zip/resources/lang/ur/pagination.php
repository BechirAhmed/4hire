<?php 

return [
    'previous' => '& laquo؛ پچھلا',
    'next' => 'اگلا & raquo؛',
];
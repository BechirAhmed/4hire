<?php 

return [
    'previous' => '& LAQUO; предыдущий',
    'next' => 'Далее & raquo;',
];